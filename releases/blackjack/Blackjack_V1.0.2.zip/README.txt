Blackjack 1.0.2 -- for SPT 4.1.x
================================

INSTALLING
    Stop the server, then extract this archive into your SPT folder: the one
    that holds SPT_Runtime. The files belong at:

        SPT_Runtime\user\mods\Blackjack\      the server mod
        BepInEx\plugins\Blackjack\             the in-game half

    Both are needed. The server deals and holds the money; the client draws the
    table and sends what you asked for.

    Start the server. "Blackjack" should appear in the mod list, and a BLACKJACK
    entry on the game's main menu.

    There is an installer as well, if you would rather not place files by hand.

PLAYING
    BLACKJACK on the main menu opens the table. Pick a currency, type a bet,
    DEAL. Escape leaves.

    Six decks, dealer stands on soft 17, blackjack pays 3:2 in currency and even
    money in valuables -- one bitcoin at 3:2 would settle on half a coin.

    You can stake roubles, dollars, euros, GP coins, bitcoin or Lega medals.
    They are your own; a hand you lose is gone.

THE TABLE MAXIMUM
    500,000 roubles a hand, 5,000 dollars or euros, 50 GP, 10 bitcoin, 5 Lega.

    It is the house's only real protection. The edge on these rules is about
    half a percent, which is nothing across a session; what stops a player
    compounding is being unable to cover a losing streak by doubling up.

    Turn it off in the BepInEx menu (F12) under Table if you would rather play
    without one. The minimum always applies.

ART
    The card faces are Chris Aguilar's Vectorized Playing Cards 1.3, from
    opengameart.org. They live in BepInEx\plugins\Blackjack\cards\ as one PNG
    per card. Delete them and the mod draws its own instead.

    The table is a photograph, table.png beside the plugin. Delete it and a
    drawn table takes its place.

https://github.com/JoelHauser/Blackjack
